//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CAN_IXXAT_VCI.rc
//
#define IDC_BUT_REMOVE                  3
#define IDC_BUT_SELECT                  5
#define IDD_IXXAT_CAN_CONFIG_DLG        101
#define IDD_IXXAT_CAN_SELECTION_DLG     102
#define IDD_DIALOG1                     104
#define IDD_DLG_HW_LISTING_CAN          130
#define IDD_DLG_HW_LISTING              130
#define IDR_BMP_NET                     204
#define IDC_CAN_EDIT_BAUD_RATE          1000
#define IDC_BUTTON_CANCFG_OK            1001
#define IDC_CANFD_EDIT_BAUD_RATE        1001
#define IDC_COMBO_CIA_BAUD_SELECTION    1002
#define IDC_BUTTON_ADVANCE              1002
#define IDC_EDIT_BITREG0                1003
#define IDC_CHECK_CANFD                 1003
#define IDC_EDIT_BITREG1                1004
#define IDC_BUTTON_CANCEL               1006
#define IDC_STATIC_INFO_TEXT            1007
#define IDC_EDIT_FIRMWARE               1008
#define IDC_LSTC_HW_LIST                1018
#define IDC_EDIT_DRIVER_ID              1019
#define IDC_STAT_LINE3                  1119
#define IDC_LSTC_SELECTED_HW_LIST       1226

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
