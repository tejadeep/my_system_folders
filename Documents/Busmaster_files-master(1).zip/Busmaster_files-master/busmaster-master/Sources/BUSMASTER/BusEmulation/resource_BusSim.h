//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BusEmulation.rc
//
#define IDS_PROJNAME                    100
#define IDR_BUSEMULATION                101
#define IDR_SIMENG                      102
