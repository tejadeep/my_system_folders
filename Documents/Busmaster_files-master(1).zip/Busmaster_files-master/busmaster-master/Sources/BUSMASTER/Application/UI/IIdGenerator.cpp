#include "..\stdafx.h"
#include "IIdGenerator.h"


IIdGenerator::IIdGenerator()
{
}


IIdGenerator::~IIdGenerator()
{
}
