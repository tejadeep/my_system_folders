#ifndef __BUSMASTER_CAN_INCLUDES_
#define __BUSMASTER_CAN_INCLUDES_

#pragma GCC diagnostic ignored "-Wwrite-strings"
#include "BMCANDefines.h"
#include "CANCAPLWrapper.h"
#endif