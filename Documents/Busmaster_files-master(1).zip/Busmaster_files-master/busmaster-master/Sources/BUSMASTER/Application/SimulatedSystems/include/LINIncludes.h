#ifndef __BUSMASTER_LIN_INCLUDES_
#define __BUSMASTER_LIN_INCLUDES_

#pragma GCC diagnostic ignored "-Wwrite-strings"
#include "BMLINDefines.h"


#endif