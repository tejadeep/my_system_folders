#pragma once

class IBusmasterPluginConnection
{
public:
    void getPluginId(char* id);
};