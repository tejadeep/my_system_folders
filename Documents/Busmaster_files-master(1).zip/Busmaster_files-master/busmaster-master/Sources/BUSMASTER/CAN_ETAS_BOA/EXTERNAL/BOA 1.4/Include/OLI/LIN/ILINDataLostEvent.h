/*
* Basic Open API - Open Link Interface
* Version 1.3
*
* Copyright (c) ETAS GmbH. All rights reserved.
*
* $Revision: 4794 $
*/

/**
* @file
* @brief  ILINDataLostEvent definition
* @remark The header structure of the OLI may change
*         in future releases. Don't include this
*         header directly. Use @ref OLI.h instead.
*/

#if !defined(__OLI_ILINDATALOSTEVENT__INCLUDED__)
#define __OLI_ILINDATALOSTEVENT__INCLUDED__

// include used interface and constants

#include "LINBase.h"
#include "../Common/IEvent.h"

// open ETAS::OLI namespace

#include "../Common/BeginNamespace.h"

#ifdef _DOXYGEN
namespace ETAS
{
namespace OLI
{
#endif

/**
* @ingroup GROUP_OLI_LIN_MESSAGES
* @brief  Event to signal that LIN frames got lost.
*
* Extends the base interface by adding a method to get the number
* frames being lost.
*
* This interface's implementation of @ref IMessage::GetID always returns 0.
*
* @remark All public methods are thread-safe.
* @remark The lifetime of all objects implementing this interface
*         is defined by the @ref IRxQueue "receive queue" instance
*         that contains them.
* @since  BOA 1.3
* @see    IRxQueue, ILINLink, ILINDataLostEventFilter
*/

OLI_INTERFACE ILINDataLostEvent :
public IEvent
{
protected:

    /** @brief Destructor.

        This destructor has been hidden since objects implementing
        this class are controlled by the receiving queue.

        @exception <none> This function must not throw exceptions.

        @since  BOA 1.3
     */
    virtual ~ILINDataLostEvent() OLI_NOTHROW {};

public:

    /** The unique identifier for the type of this interface
        and will be returned by @ref IMessage::GetType.
     */
    enum {TYPE = LIN_TYPE_EVENT_BASE + 1};

    /** @brief  Get the number of lost frames.

        @return Number of lost frames.
        @exception <none> This function must not throw exceptions.

        @since  BOA 1.3
     */
    virtual uint32 OLI_CALL GetCount() const OLI_NOTHROW = 0;
};

// close ETAS::OLI namespace

#ifdef _DOXYGEN
}
}
#endif

#include "../Common/EndNamespace.h"

#endif // !defined(__OLI_ILINDATALOSTEVENT__INCLUDED__)
