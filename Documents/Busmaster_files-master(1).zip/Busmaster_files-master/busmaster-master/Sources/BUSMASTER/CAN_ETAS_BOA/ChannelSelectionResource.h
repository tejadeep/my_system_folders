//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CAN_ETAS_BOA.rc
//
#define IDOK                            1
#define IDC_BUT_REMOVE                  3
#define IDC_BUT_SELECT                  5
#define IDD_DLG_HW_LISTING              130
#define IDD_DLG_HW_LISTING_CAN          130
#define IDR_BMP_NET                     204
#define IDC_EDIT_BAUD_RATE              1000
#define IDC_CAN_EDIT_BAUD_RATE          1000
#define IDC_EDIT_DATA_BAUD_RATE         1001
#define IDC_CANFD_EDIT_BAUD_RATE        1001
#define IDC_STATIC_TX                   1002
#define IDC_BUTTON_ADVANCE              1002
#define IDC_STATIC_SEC_SMPL_POINT       1003
#define IDC_CHECK_CANFD                 1003
#define IDC_STATIC_SMPL_POINT           1004
#define IDC_STATIC_BTL                  1005
#define IDC_STATIC_SJW                  1006
#define IDC_EDIT_NET_NAME               1007
#define IDC_EDIT_COMPENSATION_FILTER    1007

#define IDC_EDIT_FIRMWARE               1008
#define IDC_SECONDARY_SAMPLE_POINT      1009
#define IDC_EDGE_FILTER                 1010
#define ICE                             1012
#define IDC_STAT_BAUD_RATE              1013
#define IDC_STAT_KBPS                   1014
#define IDC_STAT_BUAD_RATE              1015
#define IDC_STAT_BUAD_RATE2             1016
#define IDC_STAT_BUAD_RATE3             1017
#define IDC_STAT_KBPS2                  1018
#define IDC_LSTC_HW_LIST                1018
#define IDC_COMB_SAMPLING               1019
#define IDC_EDIT_DRIVER_ID              1019
#define IDC_STATIC_SEC_SMPL_POINT_FILTER 1020
#define IDC_COMB_SJW                    1023
#define IDC_COMB_BTL                    1024
#define IDC_COMB_DATA_BTL               1025
#define IDC_COMB_DATA_SJW               1026
#define IDC_COMB_DELAY_COMPENSATION     1028
#define IDC_COMB_DELAY_COMPENSATION3    1030
#define IDC_ButtonOK                    1060
#define IDC_STAT_LINE3                  1119
#define IDC_EDIT_WARNING_LIMIT          1175
#define IDC_EDIT_COMPENSATION_QUANTA    1176
#define IDC_EDIT_ACCEPTANCE_CODE2       1181
#define IDC_CBTN_ACCETANCE_OK           1200
#define IDC_EDIT_ACCEPTANCE_MASK2       1201
#define IDC_EDIT_ACCEPTANCE_CODE3       1202
#define IDC_EDIT_ACCEPTANCE_MASK3       1203
#define IDC_EDIT_ACCEPTANCE_MASK1       1204
#define IDC_EDIT_ACCEPTANCE_MASK4       1205
#define IDC_EDIT_ACCEPTANCE_CODE1       1206
#define IDC_EDIT_ACCEPTANCE_CODE4       1207
#define IDC_RBTN_SINGLE_FILTER_MODE     1208
#define IDC_RBTN_DUAL_FILTER_MODE       1209
#define IDC_STAT_FILTER_MODE            1210
#define IDC_STAT_ACCEPTANCE_FILTER_CODE 1211
#define IDC_STAT_ACCEPTANCE_FILTER_MASK 1212
#define IDC_LSTC_SELECTED_HW_LIST       1226
#define IDC_LIST_CHANNELS               1246
#define IDC_EDIT_INITFILE               3001
#define IDC_BUTTON1                     3002
#define IDC_BUTTON_APPLY                3003
#define IDC_LIST1                       3004
#define IDD_DLG_CHANGE_REGISTERS_CAN_ETAS_BOA 3004
#define IDC_NAME                        3005
#define IDC_VENDOR                      3006
#define IDC_DESC                        3007
#define IDR_PGM_EDTYPE                  3007
#define IDC_CHECK_SELF_REC              3010
#define IDC_COMB_SAMPOINT               3011
#define IDC_EDIT_CHANNEL_DESC           3012
#define IDC_COMB_DATA_SAMPOINT          3013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
